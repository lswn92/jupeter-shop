export class Account {
    constructor(
        public email: string,
        public name: string, 
        public tel: string, 
        public status: string,
        public id: string) {}
}